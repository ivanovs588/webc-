If you want to contribute, please follow the existing style.

This means:
 * Files and folders should be named like this: FolderName, FileName.txt - each word starts with a capital letter.
 * Use tabs, not spaces, for code indentation.
 * No extra spaces in code. ( a=b, not a = b)
 * Use this style of placing brackets:
	void main()
	{
	}
   but not this:
	void main() {
	}
 * And so on. (take a look at the code itself)
