Be sure that you have Visual C++ 2008 Redistributable installed.

You can get it from here:
http://www.microsoft.com/downloads/details.aspx?familyid=9B2DA534-3E03-4391-8A4D-074B9F2BC1BF&displaylang=en